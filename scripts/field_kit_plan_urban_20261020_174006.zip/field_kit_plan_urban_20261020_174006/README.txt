FIELD KIT (PLANTING BLOCKS) - plan_urban_20261020_174006
==============================================================================
Plan id      : plan_urban_20261020_174006
Check code   : 56c30520   (first 8 characters of the sha256 of the plan CSV;
               if the plan changes, the code changes. Only use files with the same code.)
Dataset      : v1.0-review   hash 34964a09fe44
Built on     : 2026-10-20      Purpose: urban
Trees        : 20 trees in 1 blocks (about 1.0 ha of planting squares)

WHAT IS IN THIS KIT
  points.gpx      one waypoint per BLOCK for a phone map app     blocks.csv      the sheet to fill in the field (open in Excel)
  points.kml      same blocks, one folder per species             point-list.csv  the same blocks in the older sheet format
  field-map.pdf   printed map, one page per block, table (only if made)     manifest.json   every file with its size and sha256

WHAT IS A BLOCK
  A block is one 100 m x 100 m grid square planted at the species spacing, so that many trees stand close together. The planted area is a square of
  (trees per row x spacing) metres on each side, CENTRED in the grid square, so the same margin is left on all four sides for paths, boundaries and rocks.
  For NAR that is 75 m x 75 m with a margin of 12.5 m. Each waypoint is named like NAR-B01 (species code, B for block, number) and
  is the CENTRE of the grid square. Tap it to read the layout. The corners of the planted area are waypoints too: NAR-B01-START (south-west), -SE, -NE, -NW.

HOW TO LAY OUT A BLOCK (a tape measure or pacing is enough)
  1. Walk to the NAR-B01-START waypoint (or to the block waypoint and then go to the corner). START is the south-west corner of the planted area.
     In blocks.csv the same corner is in start_lat / start_lon; first_tree_lat / first_tree_lon is tree 1. Put a stake at START.
  2. Tree 1 is half a spacing east and half a spacing north of START (for NAR: 6.25 m each). Trees stand at the CENTRES of the cells of the planted area,
     so the first tree is 18.75 m from the south and west edges of the grid square.
  3. Rows run east-west (the grid is assumed to be aligned to UTM north: this is an assumption, check it with the compass of the phone). Plant tree 1, then walk east and plant a tree
     every spacing (a tape, a marked rope, or count paces: one adult pace is about 0.75 m, so a spacing of 7.5 m is 10 paces). The row is full after the number of trees per row.
  4. Go north by one spacing and plant the next row from the west end. Number the trees in your head row by row. A block that holds fewer trees than its capacity plants trees
     1 to N in that order, so the last row may be short: leave the rest empty (the printed page of each block shows which).
  5. Use the other corners (SE, NE, NW) to check that the area is square: the sides are the same length. With two tapes or a rope you can set out the corners first and then divide the sides.
  6. If a house, road, creek or an existing tree is in the way, move the tree or the block (up to 10 m) and write the real position in moved_lat and moved_lon. Never plant on paved or built land.
  7. If the notes say "Plant along the contour" (slope above 30%), run the rows along the contour lines instead of straight east-west.
  8. COUNT the trees you really planted in each block (do not count missing or dead saplings) and write the number in blocks.csv.

SPACING AND CAPACITY OF THE SPECIES IN THIS PLAN
  NAR  Narra                      every 12.5 m, 6 rows of 6 trees = 36 trees in a full block

GPS AND THE 100 m SQUARE
  - GPS accuracy is a few metres in the open, and worse under tree cover, near buildings or in a gully: GPS is good to a few metres and worse under trees, and the square is a map cell, not an exact planting spot.
  - The waypoint is the centre of the square, not a surveyed spot. If the planted area meets a rock, a tree, a creek bank or a path, you may shift the block by up to
    10 m. Write the REAL position of the block's centre in moved_lat and moved_lon (decimal degrees, from the phone).
  - Dioecious species need BOTH sexes: plant male and female trees of that species in the same block.
  - Plant only in the planting months listed for the species.
  - A block flagged zoning_unconfirmed is on land outside our zoning map; the CLUP 2021-2031 shows it as Forest Reserve (Watershed): coordinate with MENRO and DENR before planting there.
  - The flag soil_provisional means the soil of the block comes from the LGU soil map, digitized by us: provisional, not yet verified by the agriculturist.
  - A block flagged ground_bare, ground_built_up or ground_water looks bare, built-up or like water in satellite land cover (ESA WorldCover 2021, 76.7% accurate worldwide): check it on the ground first.

BRINGING THE RESULTS BACK
  When you are done, fill blocks.csv: write "planted" in the status column and the number of trees you planted in trees_planted (from 0 up to trees_planned; fewer trees means the
  block is only partly done). For a block that cannot be planted write the reason in status (paved, building, rock_or_ledge, creek_or_waterlogged, too_steep, existing_tree,
  owner_refused or other). If you moved the block, also fill moved_lat and moved_lon. Then open the dashboard, type your name, and press "Import field checks (CSV)" and choose
  blocks.csv. The plan id and the check code in the file must match this kit, or it is refused. Importing the same file twice adds nothing. (point-list.csv works too: "planted"
  means all the trees of the block.)

SPECIES CODES AND TREES
  NAR  Narra                        20 trees

KNOWN LIMITS (from the plan)
  - Each block is one 100 m grid square, planted at the species spacing on its usable part (provisional share of the square); a plan places at most one block per square.
  - Block layout (usable share, spacing rounding, capacity) is provisional until the agriculturist signs it off.
  - Weights, caps and thresholds are provisional; site scores use the soft soil mode (texture mapping unverified).
  - S comes from a Random Forest trained on expert rules (the rule limits for zone, elevation and steep slope apply first), not from field survival data.
  - Hindi kasama sa score ang pH, ulan at temperatura.
  - Ang mga square na walang datos ng lupa ay walang soil data: hindi isinasama ang lupa sa score nila, kaya hindi sila pinaparusahan at maaaring mas mataas ang score kaysa sa tunay.
  - Hindi pa verified ng agriculturist ang species data (release v1.0-review).
  - Existing trees: no trees table given: no exclusion zone applied.
